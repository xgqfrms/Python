ifconfig
========

.. ifconfig:: confval1

   spam

.. ifconfig:: confval2

   egg

