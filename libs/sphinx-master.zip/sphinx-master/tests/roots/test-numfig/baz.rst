Baz A
-----

.. _fig22:

.. figure:: rimg.png

   should be Fig.2.2

.. _table22:

.. csv-table:: should be Table 2.2
   :header-rows: 0

   hello,world

.. _CODE22:

.. code-block:: python
   :caption: should be List 2.2

   print('hello world')
